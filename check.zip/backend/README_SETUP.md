PERSONAL GROWTH TRACKER - BACKEND
=================================

This package contains the backend folder for the Personal Growth Tracker.

1. Extract the ZIP file.
2. Copy the included "backend" folder into your project folder, replacing
   the corresponding backend files after keeping a backup of your current work.
3. Open PowerShell in the backend folder.
4. Activate your existing virtual environment if it is not already active:

   .\venv\Scripts\Activate.ps1

   If your venv is in the project root rather than inside backend, activate it
   using the correct relative path, for example:

   ..\venv\Scripts\Activate.ps1

5. Install the dependencies:

   pip install -r requirements.txt

6. Set a secret key for the current PowerShell session:

   $env:SECRET_KEY = python -c "import secrets; print(secrets.token_urlsafe(48))"

   Keep the same key while using the app. If you generate a new key each time,
   existing login tokens will stop working.

7. Start the API:

   uvicorn main:app --reload

8. Open the API documentation:

   http://127.0.0.1:8000/docs

The SQLite database is created automatically in the backend working directory
as personal_growth_tracker.db.

IMPORTANT NOTES
---------------

- This is a fresh, consistent backend implementation. Back up your existing
  backend before replacing files.
- Existing database schemas are not automatically migrated. If you already
  have a database from a previous version, back it up before testing. For a
  development database with no data you need to keep, you may remove the old
  .db file so the new schema can be created.
- Passwords are hashed using PBKDF2 from Python's standard library.
- OAuth2 login expects the email in the form field named "username" and the
  password in the form field named "password".
- Frontend requests must send the access token as:
  Authorization: Bearer YOUR_TOKEN
- Profile pictures are served from /uploads/profile_pictures/...
- Report PDF is served inline at /reports/pdf, which can open in a browser tab
  when the frontend opens the URL with the required authentication handling.

PROGRESS CALCULATION
--------------------

Each goal's activity component uses activities in the same category recorded
over the last seven calendar days, divided by that goal's weekly target.
If the goal has milestones, its progress is the average of activity progress
and completed-milestone percentage. If it has no milestones, activity progress
alone is used. Overall progress is the average of all goal progress values.

The current implementation associates activities with goals by matching
category. If you later want an activity to count toward one specific goal when
several goals share a category, the database will need an activity-to-goal
relationship.

FRONTEND INTEGRATION
--------------------

This backend exposes:
- /users/register
- /users/login
- /users/me
- /goals and /goals/{id}/milestones
- /activities
- /reflections
- /achievements
- /profile and /profile/picture
- /profile/settings
- /reports and /reports/pdf

Check /docs for the full request and response schemas.
