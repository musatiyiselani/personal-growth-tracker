from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# Authentication and users

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(ORMModel):
    id: int
    name: str
    email: EmailStr
    bio: Optional[str] = None
    profile_picture: Optional[str] = None
    created_at: datetime


class UserUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    bio: Optional[str] = Field(default=None, max_length=2000)


# Goals

class GoalCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: Optional[str] = None
    category: str = Field(min_length=1, max_length=100)
    weekly_target: float = Field(default=5, gt=0, le=100000)
    start_date: date
    deadline: Optional[date] = None

    @model_validator(mode="after")
    def validate_dates(self):
        if self.deadline and self.deadline < self.start_date:
            raise ValueError("Deadline cannot be before the start date.")
        return self


class GoalUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = None
    category: Optional[str] = Field(default=None, min_length=1, max_length=100)
    weekly_target: Optional[float] = Field(default=None, gt=0, le=100000)
    start_date: Optional[date] = None
    deadline: Optional[date] = None
    # progress and status are deliberately not accepted from clients


class GoalResponse(ORMModel):
    id: int
    user_id: int
    title: str
    description: Optional[str] = None
    category: str
    status: str
    progress: float
    weekly_target: float
    start_date: date
    deadline: Optional[date] = None
    created_at: datetime


class MilestoneCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: Optional[str] = None
    completed: bool = False


class MilestoneUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = None
    completed: Optional[bool] = None


class MilestoneResponse(ORMModel):
    id: int
    goal_id: int
    title: str
    description: Optional[str] = None
    completed: bool
    completed_at: Optional[datetime] = None


# Activities

class ActivityCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: Optional[str] = None
    category: str = Field(min_length=1, max_length=100)
    duration: Optional[float] = Field(default=None, gt=0, le=100000)
    activity_date: date


class ActivityUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = None
    category: Optional[str] = Field(default=None, min_length=1, max_length=100)
    duration: Optional[float] = Field(default=None, gt=0, le=100000)
    activity_date: Optional[date] = None


class ActivityResponse(ORMModel):
    id: int
    user_id: int
    title: str
    description: Optional[str] = None
    category: str
    duration: Optional[float] = None
    activity_date: date
    created_at: datetime


# Reflections

class ReflectionCreate(BaseModel):
    title: Optional[str] = Field(default=None, max_length=200)
    content: str = Field(min_length=1)
    mood: Optional[str] = Field(default=None, max_length=50)
    reflection_date: date


class ReflectionUpdate(BaseModel):
    title: Optional[str] = Field(default=None, max_length=200)
    content: Optional[str] = Field(default=None, min_length=1)
    mood: Optional[str] = Field(default=None, max_length=50)
    reflection_date: Optional[date] = None


class ReflectionResponse(ORMModel):
    id: int
    user_id: int
    title: Optional[str] = None
    content: str
    mood: Optional[str] = None
    reflection_date: date
    created_at: datetime


# Achievements

class AchievementCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: Optional[str] = None
    achievement_date: date


class AchievementResponse(ORMModel):
    id: int
    user_id: int
    title: str
    description: Optional[str] = None
    achievement_date: date
    created_at: datetime


# Settings

class SettingsUpdate(BaseModel):
    dark_mode: Optional[bool] = None
    notifications_enabled: Optional[bool] = None
    week_start: Optional[str] = None

    @field_validator("week_start")
    @classmethod
    def validate_week_start(cls, value):
        if value is not None and value not in {
            "Monday", "Sunday", "Saturday"
        }:
            raise ValueError("Week start must be Monday, Sunday, or Saturday.")
        return value


class SettingsResponse(ORMModel):
    id: int
    user_id: int
    dark_mode: bool
    notifications_enabled: bool
    week_start: str


class DailyProgressResponse(ORMModel):
    id: int
    user_id: int
    progress_date: date
    overall_progress: float
    created_at: datetime
